#include "Login.h"
#include "ui_Login.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>
#include <QHostAddress>

Login::Login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    // add a mysql database
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    // set up database
    db.setHostName("127.0.0.1"); // IP
    db.setUserName("user"); // login username
    db.setPassword("password"); // password
    db.setDatabaseName("assignment"); // connect database

    if(db.open() == false) {
        qDebug() << "failed to open";
    }
}

Login::~Login()
{
    delete ui;
}

void Login::on_LButton_clicked()
{
    QSqlQuery query;
    query.exec("select * from userlogin");
    while (query.next()) {
        string username = query.value(1).toString().toStdString();
        string password = query.value(2).toString().toStdString();
        string accessLevel = query.value(3).toString().toStdString();
        int userid = query.value(4).toInt();
        UserLogin account(username, password, accessLevel, userid);
        accounts.push_back(account);
    }

    string username = ui->UText->text().toStdString();
    string password = ui->PText->text().toStdString();
    int userid;
    bool exist = false;

    for (int i=0; i<accounts.size(); i++) {
        if (accounts[i].getUsername() == username && accounts[i].getPassword() == password) {
            userid = accounts[i].getUserid();
            exist = true;
        }
    }

    if (exist == true) {
        QMessageBox::information(this, "information", "login successfully", QMessageBox::Ok);
        this->close();

        // init
        client = new QTcpSocket(this);
        // Connect server
        client->connectToHost(QHostAddress(QHostAddress::LocalHost), 8080);
        client->write(to_string(userid).data());
    }
    else {
        QMessageBox::critical(this, "error", "wrong username or password", QMessageBox::Ok | QMessageBox::Cancel);
        ui->UText->clear();
        ui->PText->clear();
    }
}


void Login::on_RButton_clicked()
{
    string username = ui->UText->text().toStdString();
    string password = ui->PText->text().toStdString();
    bool exist = false;

    for (int i=0; i<accounts.size(); i++) {
        if (accounts[i].getUsername() == username && accounts[i].getPassword() == password) {
            exist = true;
        }
    }

    if (exist == true) {
        QMessageBox::critical(this, "error", "user exists", QMessageBox::Ok | QMessageBox::Cancel);
    }
    else {
        rui.show();
    }
}


void Login::on_FButton_clicked()
{
    fui.show();
}

