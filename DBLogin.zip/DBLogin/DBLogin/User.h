#ifndef USER_H
#define USER_H
#include <iostream>
using namespace std;

class User
{
public:
    User();
    User(int, string, string, string);
    string getFirstname();
    string getLastname();
    int getUserid();
    string getPosition();

private:
    string firstname;
    string lastname;
    int userid;
    string position;
};

#endif // USER_H
