#include "UserLogin.h"

UserLogin::UserLogin() {}

UserLogin::UserLogin(string username, string password, string accessLevel, int userid){
    this->username = username;
    this->password = password;
    this->accessLevel = accessLevel;
    this->userid = userid;
}

string UserLogin::getUsername() {
    return username;
}

string UserLogin::getPassword(){
    return password;
}

string UserLogin::getAccessLevel() {
    return accessLevel;
}

int UserLogin::getUserid() {
    return userid;
}
