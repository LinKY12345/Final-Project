#include "User.h"

User::User() {}

User::User(int userid, string firstname, string lastname, string position){
    this->userid = userid;
    this->firstname = firstname;
    this->lastname = lastname;
    this->position = position;
}

string User::getFirstname() {
    return firstname;
}

string User::getLastname() {
    return lastname;
}

int User::getUserid() {
    return userid;
}

string User::getPosition() {
    return position;
}
