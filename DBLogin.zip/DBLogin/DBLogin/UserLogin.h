#ifndef USERLOGIN_H
#define USERLOGIN_H
#include <iostream>
using namespace std;

class UserLogin
{
public:
    UserLogin();
    UserLogin(string, string, string, int);
    string getUsername();
    string getPassword();
    string getAccessLevel();
    int getUserid();

private:
    string username;
    string password;
    string accessLevel;
    int userid;
};

#endif // USERLOGIN_H
