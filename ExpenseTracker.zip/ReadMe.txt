Please use MySQL for this project
Your database should set username: "user"
Your database should set password: "password"
Please create a database: "assignment"

CREATE TABLE User (
    userID INT PRIMARY KEY,
    firstname VARCHAR(255),
    lastname VARCHAR(255),
    position VARCHAR(255)
);

CREATE TABLE UserLogin (
    loginID INT PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    accessLevel VARCHAR(255),
    userID INT,
    UNIQUE(loginID),
    FOREIGN KEY (userID) REFERENCES User(userID)
);