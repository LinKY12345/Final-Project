#include "Transaction.h"
#include <iostream>
using namespace std;

// Constructor
Transaction::Transaction(string date, string category, string subcategory, double amount) {
	this->date = date;
	this->category = category;
	this->subcategory = subcategory;
	this->amount = amount;
}

/**
 * @brief Transaction::setDate
 * @param date
 */
void Transaction::setDate(string date) {
	this->date = date;
}

/**
 * @brief Transaction::setCategory
 * @param category
 */
void Transaction::setCategory(string category) {
	this->category = category;
}

/**
 * @brief Transaction::setSubcategory
 * @param subcategory
 */
void Transaction::setSubcategory(string subcategory) {
	this->subcategory = subcategory;
}

/**
 * @brief Transaction::setAmount
 * @param amount
 */
void Transaction::setAmount(int amount) {
	this->amount = amount;
}

/**
 * @brief Transaction::getDate
 * @return
 */
string Transaction::getDate() {
	return date;
}

/**
 * @brief Transaction::getCategory
 * @return
 */
string Transaction::getCategory() {
	return category;
}

/**
 * @brief Transaction::getSubcategory
 * @return
 */
string Transaction::getSubcategory() {
	return subcategory;
}

/**
 * @brief Transaction::getAmount
 * @return
 */
double Transaction::getAmount() {
	return amount;
}
