#include "Register.h"
#include "ui_Register.h"
#include <QSqlDatabase>
#include <QSqlQuery>

Register::Register(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Register)
{
    ui->setupUi(this);
    this->setWindowTitle("Register");

    // add a mysql database
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    // set up database
    db.setHostName("127.0.0.1"); // IP
    db.setUserName("user"); // login username
    db.setPassword("password"); // password
    db.setDatabaseName("assignment"); // connect database

    if(db.open() == false) {
        qDebug() << "failed to open";
    }

    // store information from database into lists
    QSqlQuery query;
    query.exec("select * from userlogin");
    while (query.next()) {
        string username = query.value(1).toString().toStdString();
        string password = query.value(2).toString().toStdString();
        string accessLevel = query.value(3).toString().toStdString();
        int userid = query.value(4).toInt();
        UserLogin account(username, password, accessLevel, userid);
        accounts.push_back(account);
    }

    query.exec("select * from user");
    while (query.next()) {
        int userid = query.value(0).toInt();
        string firstname = query.value(1).toString().toStdString();
        string lastname = query.value(2).toString().toStdString();
        string position = query.value(3).toString().toStdString();

        User user(userid, firstname, lastname, position);
        users.push_back(user);
    }
}

Register::~Register()
{
    delete ui;
}

// create a new account
void Register::on_CButton_clicked()
{
    string username = ui->UText->text().trimmed().toStdString();
    string password = ui->PText->text().trimmed().toStdString();
    string firstname = ui->FText->text().trimmed().toStdString();
    string lastname = ui->LText->text().trimmed().toStdString();
    string position = ui->PositionText->text().trimmed().toStdString();
    string accessLevel = ui->PositionText->text().trimmed().toStdString();
    bool exist = false;

    // to check if the username is already used
    for (int i=0; i<accounts.size(); i++) {
        if (username == accounts[i].getUsername()) {
            exist = true;
            break;
        }
    }

    if (exist == true) QMessageBox::critical(this, "error", "account with the same username exists", QMessageBox::Ok | QMessageBox::Cancel);
    else {
        // add new records to database
        int numberA = accounts.size();
        int numberU = users.size();
        int accountID = numberA + 1;
        int userID = numberU + 1001;
        User user(userID, firstname, lastname, position);
        users.push_back(user);
        UserLogin account(username, password, accessLevel, userID);
        accounts.push_back(account);

        QSqlQuery query;
        query.prepare("insert into user(userID, firstname, lastname, position) values (?, ?, ?, ?)");
        query.addBindValue(userID);
        query.addBindValue(QString::fromStdString(firstname));
        query.addBindValue(QString::fromStdString(lastname));
        query.addBindValue(QString::fromStdString(position));
        query.exec();

        query.prepare("insert into userlogin(loginID, username, password, accessLevel, userID) values (?, ?, ?, ?, ?)");
        query.addBindValue(accountID);
        query.addBindValue(QString::fromStdString(username));
        query.addBindValue(QString::fromStdString(password));
        query.addBindValue(QString::fromStdString(accessLevel));
        query.addBindValue(userID);
        query.exec();

        QMessageBox::information(this, "information", "Your account has been created", QMessageBox::Ok);
        this->close();
    }

    ui->UText->clear();
    ui->PText->clear();
    ui->FText->clear();
    ui->LText->clear();
    ui->PositionText->clear();
}
