#include "Table.h"
#include "ui_Table.h"

Table::Table(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Table)
{
    ui->setupUi(this);
}

Table::~Table()
{
    delete ui;
}
