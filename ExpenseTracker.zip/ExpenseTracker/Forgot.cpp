#include "Forgot.h"
#include "ui_Forgot.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>
using namespace std;

Forgot::Forgot(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Forgot)
{
    ui->setupUi(this);
    this->setWindowTitle("Forgot");

    // add a mysql database
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    // set up database
    db.setHostName("127.0.0.1"); // IP
    db.setUserName("user"); // login username
    db.setPassword("password"); // password
    db.setDatabaseName("assignment"); // connect database

    if(db.open() == false) {
        qDebug() << "failed to open";
    }

}

Forgot::~Forgot()
{
    delete ui;
}

// looking for the account
void Forgot::on_FButton_clicked()
{
    string firstname = ui->FText->text().toStdString();
    string lastname = ui->LText->text().toStdString();
    int userid = 0;

    // looking for the account from database
    QSqlQuery query;
    query.exec("select * from user");
    while (query.next()) {
        if (firstname == query.value(1).toString().toStdString() && lastname == query.value(2).toString().toStdString()) {
            userid = query.value(0).toInt();
        }
    }

    // to check if user is found
    if (userid == 0) QMessageBox::critical(this, "error", "no account is related", QMessageBox::Ok | QMessageBox::Cancel);
    else {
        query.prepare("select * from userlogin where userID = ?");
        query.addBindValue(userid);
        query.exec();
        query.next();

        QString username = query.value(1).toString();
        QString password = query.value(2).toString();
        // show the account's information
        QMessageBox::information(this, "information", "Username: "+username + " Password: "+password, QMessageBox::Ok);
    }
}

