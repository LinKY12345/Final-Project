#ifndef USERLOGIN_H
#define USERLOGIN_H
#include <iostream>
using namespace std;

class UserLogin
{
public:
    UserLogin();
    /**
     * @brief UserLogin
     */
    UserLogin(string, string, string, int);
    string getUsername();
    /**
     * @brief getPassword
     * @return
     */
    string getPassword();
    /**
     * @brief getAccessLevel
     * @return
     */
    string getAccessLevel();
    /**
     * @brief getUserid
     * @return
     */
    int getUserid();

private:
    string username;
    string password;
    string accessLevel;
    int userid;
};

#endif // USERLOGIN_H
