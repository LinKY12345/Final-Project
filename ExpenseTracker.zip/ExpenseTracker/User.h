#ifndef USER_H
#define USER_H
#include <iostream>
using namespace std;

class User
{
public:
    User();
    /**
     * @brief User
     */
    User(int, string, string, string);
    /**
     * @brief getFirstname
     * @return
     */
    string getFirstname();
    /**
     * @brief getLastname
     * @return
     */
    string getLastname();
    /**
     * @brief getUserid
     * @return
     */
    int getUserid();
    /**
     * @brief getPosition
     * @return
     */
    string getPosition();

private:
    string firstname;
    string lastname;
    int userid;
    string position;
};

#endif // USER_H
