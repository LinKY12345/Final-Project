#ifndef REGISTER_H
#define REGISTER_H

#include <QWidget>
#include "User.h"
#include "UserLogin.h"
#include <QMessageBox>

namespace Ui {
class Register;
}

class Register : public QWidget
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = nullptr);
    ~Register();

private slots:
    void on_CButton_clicked();

private:
    Ui::Register *ui;
    QList<User> users;
    QList<UserLogin> accounts;
};

#endif // REGISTER_H
