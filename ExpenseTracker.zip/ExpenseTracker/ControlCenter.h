#ifndef CONTROLCENTER_H
#define CONTROLCENTER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include "Transaction.h"
#include <QFile>
#include <QMessageBox>
#include <QtCharts>
#include <QApplication>
#include <QTableView>
#include <QStandardItemModel>

/*
 * create a control center to record information
 */
namespace Ui {
class ControlCenter;
}

class ControlCenter : public QWidget
{
    Q_OBJECT

public:
    explicit ControlCenter(QWidget *parent = nullptr);
    ~ControlCenter();

private slots:
    void on_RButton_clicked(); // recording information

    void on_GButton_clicked(); // show tableView for all records

    void on_SButton_clicked(); // show chart

    void on_GButton2_clicked(); // show tableView for all records according to a category

private:
    Ui::ControlCenter *ui;
    QTcpServer* server; // Listening socket
    QTcpSocket* conn; // Connecting socket
    QList<Transaction> transactions; // recording each inforamtion
    int userid;
    QStandardItemModel model;
    QStandardItemModel model2;
};

#endif // CONTROLCENTER_H
