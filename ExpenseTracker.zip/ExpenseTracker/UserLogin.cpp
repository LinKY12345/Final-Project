#include "UserLogin.h"

UserLogin::UserLogin() {}

/**
 * @brief UserLogin::UserLogin
 * @param username
 * @param password
 * @param accessLevel
 * @param userid
 */
UserLogin::UserLogin(string username, string password, string accessLevel, int userid){
    this->username = username;
    this->password = password;
    this->accessLevel = accessLevel;
    this->userid = userid;
}

/**
 * @brief UserLogin::getUsername
 * @return
 */
string UserLogin::getUsername() {
    return username;
}

/**
 * @brief UserLogin::getPassword
 * @return
 */
string UserLogin::getPassword(){
    return password;
}

/**
 * @brief UserLogin::getAccessLevel
 * @return
 */
string UserLogin::getAccessLevel() {
    return accessLevel;
}

/**
 * @brief UserLogin::getUserid
 * @return
 */
int UserLogin::getUserid() {
    return userid;
}
