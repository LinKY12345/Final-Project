#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <iostream>
using namespace std;

class Transaction {
private:
	string date;
	string category;
	string subcategory;
	double amount;

public:
    /**
     * @brief Transaction
     * @param date
     * @param category
     * @param subcategory
     * @param amount
     */
	Transaction(string date, string category, string subcategory, double amount);

    /**
     * @brief setDate
     * @param date
     */
	void setDate(string date);
    /**
     * @brief setCategory
     * @param category
     */
	void setCategory(string category);
    /**
     * @brief setSubcategory
     * @param subcategory
     */
	void setSubcategory(string subcategory);
    /**
     * @brief setAmount
     * @param amount
     */
	void setAmount(int amount);

    /**
     * @brief getDate
     * @return
     */
	string getDate();
    /**
     * @brief getCategory
     * @return
     */
	string getCategory();
    /**
     * @brief getSubcategory
     * @return
     */
	string getSubcategory();
    /**
     * @brief getAmount
     * @return
     */
	double getAmount();
};

#endif
