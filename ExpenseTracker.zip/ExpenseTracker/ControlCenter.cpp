#include "ControlCenter.h"
#include "ui_ControlCenter.h"
#include "MainWindow.h"

ControlCenter::ControlCenter(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ControlCenter)
    , model(0, 5) // 5 columns
    , model2(0, 3) // 3 columns
{
    ui->setupUi(this);
    this->setWindowTitle("Control Center");

    // instantiate
    server = new QTcpServer(this);
    // Listening
    server->listen(QHostAddress(QHostAddress::LocalHost), 8080);

    // New connection
    connect(server, &QTcpServer::newConnection, this, [=]()
    {
        // Accept socket from clients
        // sock_addr structured object == class QTcpSocket
        conn = server->nextPendingConnection();

        // Make sure conn is vaild
        connect(conn, &QTcpSocket::readyRead, this, [=]()
        {
            // Read data from the socket
            QByteArray data = conn->readAll();
            userid = data.toInt();
        });
    });
}

ControlCenter::~ControlCenter()
{
    delete ui;
}

// recording information
void ControlCenter::on_RButton_clicked()
{
    string date = ui->DText->text().toStdString();
    string category = ui->CText->text().toStdString();
    string subcategory = ui->SText->text().toStdString();
    double amount = ui->AText->text().toDouble();

    Transaction transaction(date, category, subcategory, amount);
    transactions.push_back(transaction);
    QMessageBox::information(this, "information", "A new record has been added", QMessageBox::Ok);

    ui->DText->clear();
    ui->CText->clear();
    ui->SText->clear();
    ui->AText->clear();
}

// show tableView for all records
void ControlCenter::on_GButton_clicked()
{
    QString filename = "userID" + QString::number(userid) + ".txt";
    QFile file(filename);
    double balance = 0;
    if (file.open(QFile::WriteOnly | QFile::Truncate)) {
        QTextStream stream(&file);
        stream << "Data,Category,Subcategory,Amount,Balance\n";
        for (int i=0; i<transactions.size(); i++) {
            balance = balance + transactions[i].getAmount();

            QString balanceString = QString::number(balance, 'f', 2);
            QString amountString = QString::number(transactions[i].getAmount(), 'f', 2);

            string record = transactions[i].getDate() + "," + transactions[i].getCategory() + "," +
                            transactions[i].getSubcategory() + "," + amountString.toStdString() +
                            "," + balanceString.toStdString();
            stream << QString::fromStdString(record) + "\n";
        }
        file.close();
        QMessageBox::information(this, "information", "Your file has been generated", QMessageBox::Ok);
    } else {
        QMessageBox::critical(this, "error", "can't open the file", QMessageBox::Ok | QMessageBox::Cancel);
    }

    balance = 0;
    model.clear();
    // Create a model to store the data
    model.setHorizontalHeaderLabels({"Date", "Category", "Subcategory", "Amount", "Balance"});

    // Add some data to the model
    for (int i = 0; i < transactions.size(); ++i) {
        balance = balance + transactions[i].getAmount();
        QList<QStandardItem*> rowData;

        rowData.append(new QStandardItem(QString::fromStdString(transactions[i].getDate())));
        rowData.append(new QStandardItem(QString::fromStdString(transactions[i].getCategory())));
        rowData.append(new QStandardItem(QString::fromStdString(transactions[i].getSubcategory())));
        QString amountString = QString::number(transactions[i].getAmount(), 'f', 2);
        rowData.append(new QStandardItem(amountString));
        QString balanceString = QString::number(balance, 'f', 2);
        rowData.append(new QStandardItem(balanceString));

        model.appendRow(rowData);
    }

    // Create a table view and set the model
    ui->tableView->setModel(&model);
    ui->tableView->show();
}


void ControlCenter::on_SButton_clicked() //?????????
{
    //axisX = new QDateTimeAxis();
    /*
    QString category = ui->CSText->text();
    QString subcategory = ui->SSText->text();
    QLineSeries *series = new QLineSeries();
    // Create a QDateTimeAxis for the x-axis
    QDateTimeAxis *axisX = new QDateTimeAxis;
    axisX->setFormat("MM/dd/yyyy");

    for(int i=0; i<transactions.size(); i++) {
        if (category.toStdString() == transactions[i].getCategory() && subcategory.toStdString() == transactions[i].getSubcategory()) {
            QList<QString> date = QString::fromStdString(transactions[i].getDate()).split('/');
            int month = date[0].toInt();
            int day = date[1].toInt();
            int year = date[2].toInt();
            double amount = transactions[i].getAmount();

            QDate qdate(year, month, day);
            qreal x = qdate.toJulianDay();
            series->append(x, amount);
        }
    }
    // Create a chart and add the series
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle("Simple line chart example");
    // Set the x-axis to use the QDateTimeAxis
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // Create a chart view and set the chart
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    */
    // Display the chart view
    MainWindow m;
    QLineSeries *series = new QLineSeries();
    series->append(0, 6);
    series->append(2, 4);
    series->append(3, 8);
    series->append(7, 4);
    series->append(10, 5);
    //*series << QPointF(11, 1) << QPointF(13, 3) << QPointF(17, 6) << QPointF(18, 3) << QPointF(20, 2);

    QChart *chart = new QChart();
    //chart->legend()->hide();

    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle("Simple line chart example");

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    m.setCentralWidget(chartView);
    m.resize(400, 300);
    m.show();
}

// show tableView for all records according to a category
void ControlCenter::on_GButton2_clicked()
{
    QString category = ui->CGText->text();
    QString filename = "userID" + QString::number(userid) + category + ".txt";
    QFile file(filename);
    if (file.open(QFile::WriteOnly | QFile::Truncate)) {
        QTextStream stream(&file);
        stream << "Data,Subcategory,Amount\n";
        for (int i=0; i<transactions.size(); i++) {
            if(category.toStdString() == transactions[i].getCategory()) {
                QString amountString = QString::number(transactions[i].getAmount(), 'f', 2);

                string record = transactions[i].getDate() + "," +
                                transactions[i].getSubcategory() + "," + amountString.toStdString();
                stream << QString::fromStdString(record) + "\n";
            }
        }
        file.close();
        QMessageBox::information(this, "information", "Your file has been generated", QMessageBox::Ok);
    } else {
        QMessageBox::critical(this, "error", "can't open the file", QMessageBox::Ok | QMessageBox::Cancel);
    }
    ui->CGText->clear();

    model2.clear();
    // Create a model to store the data
    model2.setHorizontalHeaderLabels({"Date", "Subcategory", "Amount"});

    // Add some data to the model
    for (int i = 0; i < transactions.size(); ++i) {
        if (category.toStdString() == transactions[i].getCategory()) {
            QList<QStandardItem*> rowData;

            rowData.append(new QStandardItem(QString::fromStdString(transactions[i].getDate())));
            rowData.append(new QStandardItem(QString::fromStdString(transactions[i].getSubcategory())));
            QString amountString = QString::number(transactions[i].getAmount(), 'f', 2);
            rowData.append(new QStandardItem(amountString));

            model2.appendRow(rowData);
        }
    }

    // Create a table view and set the model
    ui->tableView->setModel(&model2);
    ui->tableView->show();
}

