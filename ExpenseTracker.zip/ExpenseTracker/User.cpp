#include "User.h"

User::User() {}

/**
 * @brief User::User
 * @param userid
 * @param firstname
 * @param lastname
 * @param position
 */
User::User(int userid, string firstname, string lastname, string position){
    this->userid = userid;
    this->firstname = firstname;
    this->lastname = lastname;
    this->position = position;
}

/**
 * @brief User::getFirstname
 * @return
 */
string User::getFirstname() {
    return firstname;
}

/**
 * @brief User::getLastname
 * @return
 */
string User::getLastname() {
    return lastname;
}

/**
 * @brief User::getUserid
 * @return
 */
int User::getUserid() {
    return userid;
}

/**
 * @brief User::getPosition
 * @return
 */
string User::getPosition() {
    return position;
}
