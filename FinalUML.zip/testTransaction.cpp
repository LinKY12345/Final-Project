#include "Transaction.h"
#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

int main() {
	vector<Transaction> allTransaction;
	Transaction item1("1/1/2023", "Pay", "", 400);
	Transaction item2("1/2/2023", "Automobile", "gas", -23.43);
	Transaction item3("1/3/2023", "Automobile", "loan", -127.48);
	Transaction item4("1/4/2023", "Automobile", "insurance", -25.8);
	allTransaction.push_back(item1);
	allTransaction.push_back(item2);
	allTransaction.push_back(item3);
	allTransaction.push_back(item4);
	double balance = 0;

	for (int i = 0; i < allTransaction.size(); i++) {
		balance = balance + allTransaction[i].getAmount();
		cout << left << setw(15) << allTransaction[i].getDate() << setw(15) << allTransaction[i].getCategory()
			<< setw(15) << allTransaction[i].getSubcategory() << setw(15) << allTransaction[i].getAmount() << setw(15) << balance << endl;
	}

	return 0;
}