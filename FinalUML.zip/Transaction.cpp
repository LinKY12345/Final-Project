#include "Transaction.h"
#include <iostream>
using namespace std;

Transaction::Transaction(string date, string category, string subcategory, double amount) {
	this->date = date;
	this->category = category;
	this->subcategory = subcategory;
	this->amount = amount;
}

void Transaction::setDate(string date) {
	this->date = date;
}

void Transaction::setCategory(string category) {
	this->category = category;
}

void Transaction::setSubcategory(string subcategory) {
	this->subcategory = subcategory;
}

void Transaction::setAmount(int amount) {
	this->amount = amount;
}

string Transaction::getDate() {
	return date;
}

string Transaction::getCategory() {
	return category;
}

string Transaction::getSubcategory() {
	return subcategory;
}

double Transaction::getAmount() {
	return amount;
}
