#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <iostream>
using namespace std;

class Transaction {
private:
	string date;
	string category;
	string subcategory;
	double amount;

public:
	Transaction(string date, string category, string subcategory, double amount);

	void setDate(string date);
	void setCategory(string category);
	void setSubcategory(string subcategory);
	void setAmount(int amount);

	string getDate();
	string getCategory();
	string getSubcategory();
	double getAmount();
};

#endif
