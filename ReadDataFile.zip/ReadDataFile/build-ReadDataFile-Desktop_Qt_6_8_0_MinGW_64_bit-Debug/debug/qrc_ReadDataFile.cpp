/****************************************************************************
** Resource object code
**
** Created by: The Resource Compiler for Qt version 6.8.0
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

static const unsigned char qt_resource_data[] = {
  // D:/VisualStudio/HW/ReadDataFile/ReadDataFile/test.txt
  0x0,0x0,0x0,0x33,
  0x48,
  0x65,0x72,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x65,0x73,0x74,0x2e,0x74,0x78,0x74,
  0x22,0xa,0x59,0x6f,0x75,0x20,0x63,0x61,0x6e,0x20,0x77,0x72,0x69,0x74,0x65,0x20,
  0x61,0x6e,0x79,0x74,0x68,0x69,0x6e,0x67,0x20,0x79,0x6f,0x75,0x20,0x77,0x61,0x6e,
  0x74,0xa,
  
};

static const unsigned char qt_resource_name[] = {
  // test.txt
  0x0,0x8,
  0xc,0xa7,0x54,0xb4,
  0x0,0x74,
  0x0,0x65,0x0,0x73,0x0,0x74,0x0,0x2e,0x0,0x74,0x0,0x78,0x0,0x74,
  
};

static const unsigned char qt_resource_struct[] = {
  // :
  0x0,0x0,0x0,0x0,0x0,0x2,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x1,
0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
  // :/test.txt
  0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,
0x0,0x0,0x1,0x8e,0x61,0xfc,0xb9,0xcf,

};

#ifdef QT_NAMESPACE
#  define QT_RCC_PREPEND_NAMESPACE(name) ::QT_NAMESPACE::name
#  define QT_RCC_MANGLE_NAMESPACE0(x) x
#  define QT_RCC_MANGLE_NAMESPACE1(a, b) a##_##b
#  define QT_RCC_MANGLE_NAMESPACE2(a, b) QT_RCC_MANGLE_NAMESPACE1(a,b)
#  define QT_RCC_MANGLE_NAMESPACE(name) QT_RCC_MANGLE_NAMESPACE2( \
        QT_RCC_MANGLE_NAMESPACE0(name), QT_RCC_MANGLE_NAMESPACE0(QT_NAMESPACE))
#else
#   define QT_RCC_PREPEND_NAMESPACE(name) name
#   define QT_RCC_MANGLE_NAMESPACE(name) name
#endif

#ifdef QT_NAMESPACE
namespace QT_NAMESPACE {
#endif

bool qRegisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);
bool qUnregisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);

#ifdef QT_NAMESPACE
}
#endif

int QT_RCC_MANGLE_NAMESPACE(qInitResources_ReadDataFile)();
int QT_RCC_MANGLE_NAMESPACE(qInitResources_ReadDataFile)()
{
    int version = 3;
    QT_RCC_PREPEND_NAMESPACE(qRegisterResourceData)
        (version, qt_resource_struct, qt_resource_name, qt_resource_data);
    return 1;
}

int QT_RCC_MANGLE_NAMESPACE(qCleanupResources_ReadDataFile)();
int QT_RCC_MANGLE_NAMESPACE(qCleanupResources_ReadDataFile)()
{
    int version = 3;
    QT_RCC_PREPEND_NAMESPACE(qUnregisterResourceData)
       (version, qt_resource_struct, qt_resource_name, qt_resource_data);
    return 1;
}

#ifdef __clang__
#   pragma clang diagnostic push
#   pragma clang diagnostic ignored "-Wexit-time-destructors"
#endif

namespace {
   struct initializer {
       initializer() { QT_RCC_MANGLE_NAMESPACE(qInitResources_ReadDataFile)(); }
       ~initializer() { QT_RCC_MANGLE_NAMESPACE(qCleanupResources_ReadDataFile)(); }
   } dummy;
}

#ifdef __clang__
#   pragma clang diagnostic pop
#endif
