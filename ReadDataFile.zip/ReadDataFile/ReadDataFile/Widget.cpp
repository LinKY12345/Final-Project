#include "Widget.h"
#include "ui_Widget.h"
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    connect(ui->selectFile, &QPushButton::clicked, this, [=]()
    {
        QString fileName = QFileDialog::getOpenFileName(this, "open file", "C:\\");

        ui->filePath->setText(fileName);

        // Create File object
        QFile file(fileName);

        // Specify the opening method
        file.open(QFile::ReadOnly);

        // Read the file
        QByteArray byteArray = file.readAll();
        // Show
        ui->textEdit->setText(byteArray);
        // Close the file
        file.close();
    });

    connect(ui->saveFile, &QPushButton::clicked, this, [=]()
    {
        // Create a file object
        QFile file(ui->filePath->text());
        // Get the text from textEdit
        QByteArray text = ui->textEdit->toPlainText().toUtf8();
        // Open the file
        file.open(QFile::WriteOnly);
        // Save the text to the file
        file.write(text);
        // Close the file
        file.close();
    });
}

Widget::~Widget()
{
    delete ui;
}
